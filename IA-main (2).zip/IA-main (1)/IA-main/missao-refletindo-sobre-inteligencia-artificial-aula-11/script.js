const caixaPrincipal = document.querySelector(".caixa-principal");
const caixaPerguntas = document.querySelector(".caixa-perguntas");
const caixaAlternativas = document.querySelector(".caixa-alternativas");
const caixaResultado = document.querySelector(".caixa-resultado");
const textoResultado = document.querySelector(".texto-resultado");

const perguntas = [
    {
        enunciado: "Agora que a IA pode criar vídeos e fazer perguntas, você acha que a forma como interagimos online vai mudar?",
        alternativas: [
            {
                texto: "Sim",
                afirmacao: "isso pode tornar as interações mais dinâmicas e personalizadas, permitindo um engajamento mais direto e eficiente."
            },
            {
                texto: "Não",
                afirmacao: "isso pode resultar em interações mais superficiais e menos humanas, com conteúdo que perde a autenticidade."
            }
        ]
    },
    {
        enunciado: "Você acha que a IA vai facilitar a criação de conteúdo para todos?",
        alternativas: [
            {
                texto: "Sim",
                afirmacao: "agora qualquer pessoa pode criar vídeos e perguntas, independentemente das habilidades técnicas, tornando a criação de conteúdo mais acessível."
            },
            {
                texto: "Não",
                afirmacao: " pode gerar uma saturação de conteúdo, com menos originalidade, já que qualquer um pode produzir sem experiência"
            }
        ]
    },
    {
        enunciado: "Agora que a IA pode fazer vídeos, você acredita que ela pode substituir os criadores de conteúdo?",
        alternativas: [
            {
                texto: "Sim",
                afirmacao: "a IA pode automatizar a criação de vídeos, especialmente para conteúdos mais simples e de demanda alta."
            },
            {
                texto: "Não",
                afirmacao: "a criatividade e a visão única dos criadores de conteúdo humanos são insubstituíveis, mesmo com a IA ajudando."


            }
        ]
    },
    {
        enunciado: "Você acha que com a IA fazendo perguntas, a comunicação vai ser mais eficiente?",
        alternativas: [
            {
                texto: "Sim",
                afirmacao: "a IA pode fazer perguntas mais rápidas e precisas, ajudando a esclarecer dúvidas de forma instantânea."
            },
            {
                texto: "Não",
            afirmacao: " a comunicação precisa de contexto emocional e de nuances que a IA ainda não consegue captar."
            }
        ]
    },
    {
        enunciado: "Agora que a IA pode criar conteúdo de forma tão fácil, você acha que isso vai afetar o valor do trabalho criativo?",
        alternativas: [
            {
                texto: "Sim",
                afirmacao: "com a IA criando conteúdo rapidamente, pode diminuir a valorização do trabalho humano, já que a produção será mais barata e rápi"
            },
            {
                texto: "Não",
                afirmacao: "o trabalho criativo humano vai continuar sendo valorizado pela originalidade, visão e emoção que a IA não pode replicar."
            }
        ]
    },
];


let atual = 0;
let perguntaAtual;
let historiaFinal = "";

function mostraPergunta() {
    if (atual >= perguntas.length) {
        mostraResultado();
        return;
    }
    perguntaAtual = perguntas[atual];
    caixaPerguntas.textContent = perguntaAtual.enunciado;
    caixaAlternativas.textContent = "";
    mostraAlternativas();
}

function mostraAlternativas(){
    for(const alternativa of perguntaAtual.alternativas) {
        const botaoAlternativas = document.createElement("button");
        botaoAlternativas.textContent = alternativa.texto;
        botaoAlternativas.addEventListener("click", () => respostaSelecionada(alternativa));
        caixaAlternativas.appendChild(botaoAlternativas);
    }
}

function respostaSelecionada(opcaoSelecionada) {
    const afirmacoes = opcaoSelecionada.afirmacao;
    historiaFinal += afirmacoes + " ";
    atual++;
    mostraPergunta();
}

function mostraResultado() {
    caixaPerguntas.textContent = "Em 2049...";
    textoResultado.textContent = historiaFinal;
    caixaAlternativas.textContent = "";
}

mostraPergunta();
